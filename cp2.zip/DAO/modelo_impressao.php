<?php
	
	# Dados para impressão

	$cabecario_posto = 'POSTO AVANCADO TRT SAO PAULO - 02ª REGIAO';
	$cabecario_setor_parte1 = 'PROTOCOLO INTEGRADO - CAPITAL';
	$cabecario_setor_parte2 = 'CASA DA ADVOCACIA E DA CIDADANIA - TRABALHISTA';
	$cabecario_setor_endereco = 'Avenida Ipiranga, 1.267 - 3ª andar - República';
	$titulo = 'CONTROLE DE PROTOCOLO';
	$cabecario_titulo = str_repeat(" ", 40-strlen($titulo)/2).$titulo;	
	$cabecario_tabela = 'DATA       CIDADE                        VARA PROCESSO(S)           CHANCELA  P';
	$rodape_usuarios = 'Cadastrado por: ';
	$rodape_recebido = 'Recebido em: ____/ ____/ 20____.';
	$rodape_assinatura_parte1 = '___________________';
	$rodape_assinatura_parte2 = 'Assinatura e Carimbo';
	$rodape_observacao = 'Observação:';

?>